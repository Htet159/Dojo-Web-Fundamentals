function addLikes(id) {
    var current_likes = document.querySelector(id);
    current_likes.innerHTML ++;
}