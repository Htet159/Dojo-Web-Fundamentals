console.log("page loaded...");

function play(element) {
    element.play();
}
function reset(element) {
    element.pause();
}