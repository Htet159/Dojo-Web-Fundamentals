function over(element) {
    element.src = "C:\Users\Legen\Documents\Coding Dojo\Web Fundamentals\Assignments\Option_K_Belt_Exam\1617143155__images\images\assets\succulents-2.jpg"
}
function out(element) {
    element.src = "C:\Users\Legen\Documents\Coding Dojo\Web Fundamentals\Assignments\Option_K_Belt_Exam\1617143155__images\images\assets\succulents-1.jpg"
}